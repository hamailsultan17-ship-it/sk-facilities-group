<?php
/**
 * Horticulture dropdown ke 4 pages ka content (format security_pages.php / cleaning_pages.php jaisa).
 * Images: assets/img/horticulture-1..4.jpg pehle se maujood hain. Alag image chahiye to
 * 'img' ka naam badlo aur assets/img/ mein us naam se file rakh do.
 */
return [

    'grounds-maintenance' => [
        'file'  => 'grounds-maintenance.php',
        'nav'   => 'Grounds Maintenance',
        'h1'    => 'Grounds Maintenance',
        'title' => 'Grounds Maintenance',
        'desc'  => 'Regular mowing, edging, weeding and litter picking from SK Facilities Group, keeping your grounds tidy, safe and welcoming all year round.',
        'sections' => [
            ['type' => 'row', 'img' => 'grounds-mowing', 'imglabel' => 'Grounds maintenance image', 'imgalt' => 'Groundskeeper mowing a neat lawn',
             'heading' => 'Grounds that always look cared for',
             'paras' => [
                'The outside of your premises is the first thing visitors, customers and staff see. Well-kept grounds say that your business pays attention to detail.',
                'Our grounds maintenance team visits on a regular schedule to keep lawns, borders, paths and car parks tidy, safe and welcoming, whatever the season.',
                'We agree a plan around your site and your budget, so you know exactly what is being done and when.',
             ]],
            ['type' => 'grid', 'heading' => 'What is included',
             'items' => [
                ['Mowing and edging', 'Regular grass cutting and crisp edges that keep lawns and verges looking sharp.'],
                ['Weeding and bed care', 'Borders, beds and hard surfaces kept clear of weeds so planting can thrive.'],
                ['Litter picking', 'Grounds, car parks and boundaries cleared of litter and debris on every visit.'],
                ['Paths and hard surfaces', 'Sweeping and clearing of paths, entrances and parking areas to reduce slip and trip risks.'],
                ['Leaf and debris clearance', 'Autumn leaves and storm debris removed before they become a hazard.'],
                ['Flexible visit schedules', 'Weekly, fortnightly, monthly or seasonal visits to suit the way your site is used.'],
             ]],
            ['type' => 'gallery', 'heading' => 'Our grounds work',
             'items' => [
                ['grounds-gallery-trimmer', 'Lawn edging'],
                ['grounds-litter-picking', 'Litter picking'],
                ['grounds-gallery-weeding', 'Weeding & bed care'],
                ['grounds-gallery-paths', 'Paths & hard surfaces'],
                ['grounds-gallery-leaves', 'Leaf clearance'],
                ['grounds-gallery-garden-path', 'Garden paths & entrances'],
                ['grounds-gallery-strimming', 'Strimming & trimming'],
                ['grounds-gallery-sowing', 'Sowing & planting'],
                ['grounds-gallery-soil', 'Soil preparation'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'grounds-community-garden', 'imglabel' => 'Grounds maintenance image 2', 'imgalt' => 'Team planting and tending raised beds',
             'heading' => 'A reliable team, visit after visit',
             'paras' => [
                'We send a consistent, trained team who get to know your site, so standards stay high and nothing gets missed.',
                'You get a named point of contact, clear communication and a service that adapts as your grounds and your needs change.',
             ],
             'list' => ['Site survey and written plan before we start', 'Trained, uniformed grounds staff', 'Simple, predictable pricing']],
        ],
    ],

    'landscaping-planting' => [
        'file'  => 'landscaping-planting.php',
        'nav'   => 'Landscaping & Planting',
        'h1'    => 'Landscaping & Planting',
        'title' => 'Landscaping & Planting',
        'desc'  => 'Design and planting of beds, borders and green spaces for businesses, creating outdoor areas that make a strong first impression.',
        'sections' => [
            ['type' => 'row', 'img' => 'landscaping-planting-1', 'imglabel' => 'Landscaping image', 'imgalt' => 'Planting a young tree seedling',
             'heading' => 'Make a good first impression',
             'paras' => [
                'Thoughtful landscaping turns an ordinary entrance, car park or courtyard into a space people enjoy being in.',
                'We design and plant beds, borders and green areas that suit your site, your branding and the level of upkeep you want, from low-maintenance schemes to richer displays.',
                'Whether you are refreshing a tired area or starting from bare ground, we will talk it through with you and agree a plan before any work begins.',
             ]],
            ['type' => 'grid', 'heading' => 'How we can help',
             'items' => [
                ['Planting design', 'Plant choices matched to your soil, light and exposure, so they establish well and last.'],
                ['Beds and borders', 'New or refreshed beds, edging and mulching for a clean, finished look.'],
                ['Turf and lawns', 'Laying and renovating lawns and grassed areas on commercial and residential sites.'],
                ['Low-maintenance schemes', 'Hard-wearing planting that looks good without needing constant attention.'],
                ['Planters and entrances', 'Containers and focal planting that welcome visitors at the front door.'],
                ['Ongoing aftercare', 'We can keep your new planting healthy with regular maintenance visits.'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'landscaping-planting-2', 'imglabel' => 'Landscaping image 2', 'imgalt' => 'Family relaxing in a landscaped garden and patio',
             'heading' => 'From idea to finished space',
             'paras' => [
                'We keep the process simple. We visit your site, listen to what you need, agree a scheme and budget, and then deliver it with minimum disruption to your day-to-day business.',
             ],
             'list' => ['Site visit and no-obligation discussion', 'Clear scheme and price agreed up front', 'Tidy, considerate installation']],
        ],
    ],

    'hedge-tree-care' => [
        'file'  => 'hedge-tree-care.php',
        'nav'   => 'Hedge & Tree Care',
        'h1'    => 'Hedge & Tree Care',
        'title' => 'Hedge & Tree Care',
        'desc'  => 'Safe trimming, shaping and clearance of hedges and trees around buildings, car parks and boundaries from SK Facilities Group.',
        'sections' => [
            ['type' => 'row', 'img' => 'hedge-tree-care-1', 'imglabel' => 'Hedge and tree care image', 'imgalt' => 'Close-up of a neat hedge beside a road',
             'heading' => 'Healthy hedges, safe trees',
             'paras' => [
                'Overgrown hedges and trees can block sightlines, damage property and create hazards for people on your site.',
                'Our team trims, shapes and clears hedges and trees safely and tidily, keeping boundaries neat, paths clear and your premises looking cared for.',
                'Work is planned around your site, with sensible attention to access, public safety and the time of year.',
             ]],
            ['type' => 'grid', 'heading' => 'Our hedge and tree services',
             'items' => [
                ['Hedge trimming', 'Regular cutting and shaping for neat, healthy hedges along boundaries and car parks.'],
                ['Hedge reduction', 'Reducing overgrown hedges back to a manageable size and shape.'],
                ['Crown lifting and thinning', 'Lifting and thinning to let in light and keep paths and signage clear.'],
                ['Clearance and removal', 'Cutting back and removing unwanted growth, with all waste taken away.'],
                ['Storm damage clear-up', 'Prompt help clearing fallen branches and debris after bad weather.'],
                ['Safety and tidiness', 'Work areas managed safely and left clean when we finish.'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'hedge-tree-care-2', 'imglabel' => 'Hedge and tree care image 2', 'imgalt' => 'Site team reviewing plans before work starts',
             'heading' => 'Planned around your site',
             'paras' => [
                'We survey your site first, agree what needs doing and when, and carry the work out with minimum disruption to your staff and visitors.',
             ],
             'list' => ['Site assessment before work starts', 'Trained operatives with the right equipment', 'All waste removed from site']],
        ],
    ],

    'seasonal-displays-cleanup' => [
        'file'  => 'seasonal-displays-cleanup.php',
        'nav'   => 'Seasonal Displays & Clean-up',
        'h1'    => 'Seasonal Displays & Clean-up',
        'title' => 'Seasonal Displays & Clean-up',
        'desc'  => 'Seasonal planting, leaf clearance and tidy-ups so your grounds are ready whatever the weather, from SK Facilities Group.',
        'sections' => [
            ['type' => 'row', 'img' => 'seasonal-displays-1', 'imglabel' => 'Seasonal displays image', 'imgalt' => 'Spring flowers, boots and watering can',
             'heading' => 'Ready for every season',
             'paras' => [
                'Your grounds change through the year, and so do their needs. Spring planting, summer colour, autumn leaf fall and winter tidy-ups all take planning.',
                'We look after each season for you, so your premises always look fresh and stay safe underfoot, whatever the weather is doing.',
                'Book one-off clean-ups or add seasonal visits to a regular grounds maintenance plan.',
             ]],
            ['type' => 'grid', 'heading' => 'Through the year',
             'items' => [
                ['Spring planting', 'Fresh planting and bed preparation to bring your site back to life after winter.'],
                ['Summer displays', 'Colourful containers and borders that keep entrances looking their best.'],
                ['Autumn leaf clearance', 'Leaves cleared from paths, car parks and drains before they cause problems.'],
                ['Winter tidy-ups', 'Cutting back, clearing and general tidying to prepare your grounds for the colder months.'],
                ['One-off clean-ups', 'A full tidy before an inspection, event, sale or open day.'],
                ['Waste removal', 'Green waste collected and taken away so your site is left spotless.'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'seasonal-displays-2', 'imglabel' => 'Seasonal clean-up image 2', 'imgalt' => 'Gloved hand tending a flower bed with a hand rake',
             'heading' => 'Flexible and dependable',
             'paras' => [
                'Tell us what you need and when. We will agree a plan that fits your calendar and budget, and turn up when we say we will.',
             ],
             'list' => ['One-off or recurring visits', 'Clear pricing, agreed up front', 'Friendly, reliable teams']],
        ],
    ],

];
