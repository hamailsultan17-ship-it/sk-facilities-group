<?php /* Shared enquiry form (index.php + contact.php). Needs $serviceOptions and $_SESSION['csrf']. Optional $quoteHeading. */
$quoteHeading = $quoteHeading ?? 'Get a Quick Quote:'; ?>
<!-- QUOTE / ENQUIRY FORM -->
<section class="quote" id="quote">
  <div class="wrap quote__in" data-form-wrap>
    <div class="quote__panel" data-form-panel>
      <h2><?= e($quoteHeading) ?></h2>
      <form class="qf" method="post" action="api/submit.php" novalidate data-contact-form>
        <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
        <div class="hp" aria-hidden="true"><label>Leave this empty<input type="text" name="sk_trap_q7" tabindex="-1" autocomplete="off" data-lpignore="true" data-1p-ignore="true"></label></div>
        <div class="qf__alert" role="alert" data-form-alert hidden></div>
        <div class="qf__grid">
          <div class="field"><label class="sr" for="f-name">Name</label>
            <input id="f-name" name="name" type="text" placeholder="Name" autocomplete="name" required maxlength="100"><small class="field__err" data-err-for="name"></small></div>
          <div class="field"><label class="sr" for="f-phone">Phone</label>
            <input id="f-phone" name="phone" type="tel" placeholder="Phone" autocomplete="tel" maxlength="25"><small class="field__err" data-err-for="phone"></small></div>
          <div class="field"><label class="sr" for="f-email">Email</label>
            <input id="f-email" name="email" type="email" placeholder="Email" autocomplete="email" required maxlength="150"><small class="field__err" data-err-for="email"></small></div>
          <div class="field"><label class="sr" for="f-business">Business Name</label>
            <input id="f-business" name="business" type="text" placeholder="Business Name" autocomplete="organization" maxlength="120"></div>
          <div class="field field--full"><label class="sr" for="f-service">Service</label>
            <select id="f-service" name="service"><option value="">Service you are interested in (optional)</option>
            <?php foreach ($serviceOptions as $o): ?><option><?= e($o) ?></option><?php endforeach; ?></select></div>
          <div class="field field--full"><label class="sr" for="f-message">Message</label>
            <textarea id="f-message" name="message" rows="5" placeholder="Message" required maxlength="2000"></textarea><small class="field__err" data-err-for="message"></small></div>
        </div>
        <button class="btn" type="submit" data-submit><span data-submit-label>Submit</span></button>
        <div class="qf__success" data-form-done role="status" aria-live="polite" hidden>
          <span class="qf__tick"><?= icon('check') ?></span>
          <strong>Your message has been sent successfully!</strong>
        </div>
      </form>
    </div>
  </div>
</section>
