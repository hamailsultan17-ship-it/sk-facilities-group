<?php
/* Shared <head> + header. Set before including: $pageTitle, $pageDesc, $current ('home'|'about'|...), optional $withSchema.
   $home = '' on the landing page (plain #anchors), 'index.php' on every other page. */
$home    = $home ?? '';
$current = $current ?? '';
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?></title>
<meta name="description" content="<?= e($pageDesc) ?>">
<meta name="theme-color" content="#0B3D3A">
<link rel="icon" href="assets/img/favicon.png" type="image/png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Anton&family=Mulish:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="assets/css/style.css?v=23">
<?php if (!empty($withSchema)): ?><script type="application/ld+json"><?= json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'Organization',
    'name'     => $SITE['legal'],
    'telephone'=> $SITE['phone'],
    'email'    => $SITE['email'],
    'foundingDate' => '2026-06-01',
    'address'  => ['@type' => 'PostalAddress', 'streetAddress' => 'Flat 1-6 2 Castle Street', 'addressLocality' => 'Londonderry', 'addressRegion' => 'Northern Ireland', 'postalCode' => 'BT48 6HQ', 'addressCountry' => 'GB'],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script><?php endif; ?>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>

<!-- 1. LOGO + MENU -->
<header class="header" id="top"><div class="wrap header__in">
  <a class="brand" href="<?= $home ?>#top" aria-label="<?= e($SITE['name']) ?> – home"><span class="brand__crop"><img src="assets/img/logo.png" width="640" height="640" alt="<?= e($SITE['name']) ?> – <?= e($SITE['tagline']) ?>"></span></a>
  <button class="burger" type="button" aria-expanded="false" aria-controls="nav" aria-label="Open menu"><span></span><span></span><span></span></button>
  <nav class="nav" id="nav" aria-label="Main">
    <ul class="nav__list">
      <li class="nav__item"><a class="nav__link<?= $current === 'about' ? ' is-current' : '' ?>" href="about.php">About Us</a></li>
      <li class="nav__item has-sub">
        <a class="nav__link<?= $current === 'security' ? ' is-current' : '' ?>" href="<?= $home ?>#security">Security</a>
        <button class="nav__toggle" type="button" aria-expanded="false" aria-label="Show Security links"><?= icon('chev') ?></button>
        <ul class="nav__sub"><?php foreach ($secNav as $n): ?><li><a href="<?= e($n['url']) ?>"><?= e($n['title']) ?></a></li><?php endforeach; ?></ul>
      </li>
      <li class="nav__item has-sub">
        <a class="nav__link<?= $current === 'cleaning' ? ' is-current' : '' ?>" href="<?= $home ?>#services">Cleaning</a>
        <button class="nav__toggle" type="button" aria-expanded="false" aria-label="Show Cleaning links"><?= icon('chev') ?></button>
        <ul class="nav__sub"><?php foreach ($cleanNav as $n): ?><li><a href="<?= e($n['url']) ?>"><?= e($n['title']) ?></a></li><?php endforeach; ?></ul>
      </li>
      <li class="nav__item has-sub">
        <a class="nav__link<?= $current === 'horticulture' ? ' is-current' : '' ?>" href="<?= $home ?>#horticulture">Horticulture</a>
        <button class="nav__toggle" type="button" aria-expanded="false" aria-label="Show Horticulture links"><?= icon('chev') ?></button>
        <ul class="nav__sub"><?php foreach ($hortiNav as $n): ?><li><a href="<?= e($n['url']) ?>"><?= e($n['title']) ?></a></li><?php endforeach; ?></ul>
      </li>
      <li class="nav__item"><a class="nav__link<?= $current === 'contact' ? ' is-current' : '' ?>" href="contact.php">Contact</a></li>
      <li class="nav__item"><a class="nav__link<?= $current === 'jobs' ? ' is-current' : '' ?>" href="jobs.php">Jobs</a></li>
      <li class="nav__item"><a class="nav__link<?= $current === 'certifications' ? ' is-current' : '' ?>" href="certifications.php">Certifications</a></li>
      <li class="nav__item"><a class="nav__link<?= $current === 'blog' ? ' is-current' : '' ?>" href="blog.php">Blog</a></li>
    </ul>
  </nav>
</div></header>

