<?php
/* Shared template for the Security pages. Needs $svcKey (key of includes/security_pages.php). */
require_once __DIR__ . '/site.php';

$group = isset($secPages[$svcKey]) ? 'security' : (isset($cleanPages[$svcKey]) ? 'cleaning' : 'horticulture');
$svc = $secPages[$svcKey] ?? $cleanPages[$svcKey] ?? $hortiPages[$svcKey] ?? null;
if (!$svc) { http_response_code(404); exit('Page not found'); }

$pageTitle = $svc['title'] . ' – ' . $SITE['legal'];
$pageDesc  = $svc['desc'];
$home = 'index.php'; $current = $group;
require __DIR__ . '/header.php';

$bg = ($group === 'horticulture') ? 'assets/img/banner-horticulture.jpg' : 'assets/img/about-banner.jpg';
?>
<main id="main">

<!-- Banner -->
<section class="pagehead pagehead--svc" style="background-image:url('<?= e($bg) ?>')">
  <div class="wrap"><h1><?= e($svc['h1']) ?></h1></div>
</section>

<?php foreach ($svc['sections'] as $n => $s):
    $alt = ($n % 2 === 1) ? ' abt--alt' : ''; ?>
<?php if ($s['type'] === 'row'): ?>
<section class="abt<?= $alt ?>">
  <div class="wrap abt__row<?= !empty($s['flip']) ? ' abt__row--flip' : '' ?>">
    <div class="abt__media"><?= pic($s['img'], $s['imglabel'], $s['imgalt']) ?></div>
    <div class="abt__text">
      <h2><?= e($s['heading']) ?></h2>
      <?php foreach (($s['paras'] ?? []) as $k => $p): ?>
        <?php if ($k === 1 && !empty($s['list']) && $s['paras'] && count($s['paras']) > 1): ?>
          <ul class="ticks"><?php foreach ($s['list'] as $li): ?><li><?= icon('check') ?><span><?= e($li) ?></span></li><?php endforeach; ?></ul>
        <?php endif; ?>
        <p><?= e($p) ?></p>
      <?php endforeach; ?>
      <?php if (!empty($s['list']) && count($s['paras'] ?? []) <= 1): ?>
        <ul class="ticks"><?php foreach ($s['list'] as $li): ?><li><?= icon('check') ?><span><?= e($li) ?></span></li><?php endforeach; ?></ul>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php elseif ($s['type'] === 'gallery'): ?>
<section class="abt<?= $alt ?>">
  <div class="wrap svcgrid-wrap">
    <h2><?= e($s['heading']) ?></h2>
    <div class="gallery">
      <?php foreach ($s['items'] as $it): ?>
      <figure class="gallery__item"><?= pic($it[0], $it[1], $it[1]) ?><figcaption><?= e($it[1]) ?></figcaption></figure>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php else: ?>
<section class="abt<?= $alt ?>">
  <div class="wrap svcgrid-wrap">
    <h2><?= e($s['heading']) ?></h2>
    <?php if (!empty($s['intro'])): ?><p class="svcgrid__lead"><?= e($s['intro']) ?></p><?php endif; ?>
    <div class="svcgrid">
      <?php foreach ($s['items'] as $it): ?>
      <article class="svcgrid__item"><h3><?= e($it[0]) ?></h3><p><?= e($it[1]) ?></p></article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>
<?php endforeach; ?>

<!-- Call to action -->
<section class="svccta">
  <div class="wrap">
    <h2>Talk to us about <?= e($svc['nav']) ?></h2>
    <p>Tell us about your site and we will come back with a plan and a price that fit. Call <a href="tel:<?= e($tel) ?>"><?= e($SITE['phone']) ?></a> or email <a href="mailto:<?= e($SITE['email']) ?>"><?= e($SITE['email']) ?></a>.</p>
    <p><a class="btn" href="index.php#quote" data-pick="<?= e($svc['nav']) ?>">Get a Free Quote</a></p>
  </div>
</section>

</main>

<?php require __DIR__ . '/footer.php'; ?>
