<?php
/* Shared data for every page (index.php, about.php, ...). */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/icons.php';
require_once __DIR__ . '/db.php';   // e() helper (DB connect sirf form/chat par hota hai)

$content = json_decode(file_get_contents(__DIR__ . '/content.json'), true);
$sec     = $content['categories'][0]['items'];          // security cards
$posts   = $content['posts'];

// Security dropdown: 6 pages (includes/security_pages.php)
$secPages = require __DIR__ . '/security_pages.php';
$secNav   = array_map(fn($k, $v) => ['title' => $v['nav'], 'url' => $v['file']], array_keys($secPages), $secPages);
$secUrl   = array_column($secNav, 'url', 'title');

// Cleaning dropdown: 4 pages (includes/cleaning_pages.php)
$cleanPages = require __DIR__ . '/cleaning_pages.php';
$cleanNav   = array_map(fn($k, $v) => ['title' => $v['nav'], 'url' => $v['file']], array_keys($cleanPages), $cleanPages);
// Horticulture dropdown: 4 pages (includes/horticulture_pages.php)
$hortiPages = require __DIR__ . '/horticulture_pages.php';
$hortiNav   = array_map(fn($k, $v) => ['title' => $v['nav'], 'url' => $v['file']], array_keys($hortiPages), $hortiPages);
$tel     = preg_replace('/[^+\d]/', '', $SITE['phone']);

/**
 * Image slot: assets/img/ mein diye gaye naam ki file (.jpg .jpeg .png .webp .svg) rakh do,
 * wo khud dikh jayegi. File na ho to dotted placeholder box dikhta hai.
 */
function pic(string $name, string $label, string $alt = '', string $cls = ''): string
{
    foreach (['jpg', 'jpeg', 'png', 'webp', 'svg'] as $ext) {
        if (is_file(dirname(__DIR__) . "/assets/img/$name.$ext")) {
            return '<img class="pic ' . $cls . '" src="assets/img/' . $name . '.' . $ext . '" alt="' . e($alt) . '" loading="lazy">';
        }
    }
    return '<span class="ph ' . $cls . '" role="img" aria-label="Image placeholder"><span>' . e($label) . '<small>assets/img/' . e($name) . '.jpg</small></span></span>';
}

$horti = [
    ['leaf',   'Grounds Maintenance',        'Regular mowing, edging, weeding and litter picking to keep your site looking cared for all year round.'],
    ['flower', 'Landscaping & Planting',     'Design and planting of beds, borders and green spaces that make a good first impression.'],
    ['tree',   'Hedge & Tree Care',          'Safe trimming, shaping and clearance of hedges and trees around buildings, car parks and boundaries.'],
    ['sparkle','Seasonal Displays & Clean-up','Seasonal planting, leaf clearance and tidy-ups so your grounds are ready whatever the weather.'],
];

