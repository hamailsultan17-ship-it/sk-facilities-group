<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/phpmailer/Exception.php';
require_once __DIR__ . '/phpmailer/PHPMailer.php';
require_once __DIR__ . '/phpmailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$GLOBALS['sk_mail_error'] = '';

function mail_last_error(): string
{
    return (string)($GLOBALS['sk_mail_error'] ?? '');
}

function mail_enabled(): bool
{
    return SMTP_HOST !== '' && SMTP_USER !== '';
}

/** Ek email bhejta hai. true/false return karta hai, kabhi crash nahi hota. */
function send_mail(string $to, string $subject, string $html, string $text, ?string $replyTo = null): bool
{
    if (!mail_enabled()) { $GLOBALS['sk_mail_error'] = 'SMTP is not set up in includes/config.php'; return false; }
    $GLOBALS['sk_mail_error'] = '';
    try {
        $m = new PHPMailer(true);
        $m->isSMTP();
        $m->Host       = SMTP_HOST;
        $m->Port       = SMTP_PORT;
        $m->SMTPAuth   = true;
        $m->Username   = SMTP_USER;
        $m->Password   = SMTP_PASS;
        if (SMTP_SECURE === 'ssl')      $m->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        elseif (SMTP_SECURE === 'tls')  $m->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        else { $m->SMTPSecure = ''; $m->SMTPAutoTLS = false; }   // koi encryption nahi (sirf local testing)
        $m->Timeout    = 10;
        if (defined('SMTP_VERIFY_CERT') && !SMTP_VERIFY_CERT) {
            $m->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
        }
        $m->CharSet    = 'UTF-8';
        $m->setFrom(MAIL_FROM !== '' ? MAIL_FROM : SMTP_USER, MAIL_FROM_NAME);
        foreach (array_filter(array_map('trim', explode(',', $to))) as $addr) $m->addAddress($addr);
        if ($replyTo) $m->addReplyTo($replyTo);
        $m->isHTML(true);
        $m->Subject = $subject;
        $m->Body    = $html;
        $m->AltBody = $text;
        $ok = $m->send();
        if (!$ok) $GLOBALS['sk_mail_error'] = (string)$m->ErrorInfo;
        return $ok;
    } catch (\Throwable $ex) {
        error_log('SK mail error: ' . $ex->getMessage());
        $GLOBALS['sk_mail_error'] = mb_substr($ex->getMessage(), 0, 400);
        return false;
    }
}

function email_shell(string $title, string $inner): string
{
    global $SITE;
    $addr = implode(', ', $SITE['address']);
    return '<div style="background:#eef4f0;padding:24px;font-family:Arial,Helvetica,sans-serif;color:#1d3331">'
        . '<div style="max-width:560px;margin:auto;background:#fff;border-top:5px solid #e8622a;border-radius:8px;padding:28px">'
        . '<h2 style="margin:0 0 14px;color:#0b3d3a">' . e($title) . '</h2>' . $inner
        . '<div style="margin:24px 0 0;padding-top:14px;border-top:1px solid #d3e0da;font-size:13px;line-height:1.6;color:#56706b">'
        . '<strong style="color:#0b3d3a">' . e($SITE['legal']) . '</strong> &ndash; ' . e($SITE['tagline']) . '<br>'
        . 'Tel: ' . e($SITE['phone']) . ' &nbsp;|&nbsp; Email: ' . e($SITE['email']) . '<br>'
        . e($addr) . '<br>'
        . 'Registered in ' . e($SITE['reg_in']) . ' &ndash; company number ' . e($SITE['reg_no'])
        . '</div></div></div>';
}

function send_customer_confirmation(array $d): bool
{
    global $SITE;
    $inner = '<p>Hi ' . e($d['name']) . ',</p>'
        . '<p>Thank you for contacting SK Facilities Group. We have received your message and a member of our team will reply shortly.</p>'
        . '<p style="background:#eef4f0;padding:10px 14px;border-radius:6px;display:inline-block">Your reference: <strong>' . e($d['reference']) . '</strong></p>'
        . '<p><strong>Your message:</strong><br>' . nl2br(e($d['message'])) . '</p>'
        . '<p>Need us sooner? Call <a href="tel:' . e(preg_replace('/[^+\d]/', '', $SITE['phone'])) . '">' . e($SITE['phone']) . '</a> or email <a href="mailto:' . e($SITE['email']) . '">' . e($SITE['email']) . '</a>.</p>';
    $text = "Hi {$d['name']},\n\nThank you for contacting SK Facilities Group. We have received your message.\nYour reference: {$d['reference']}\n\nWe will reply shortly.\n\n{$SITE['legal']}\nTel: {$SITE['phone']} | Email: {$SITE['email']}\n";
    return send_mail($d['email'], 'We received your message (' . $d['reference'] . ')', email_shell('Message received', $inner), $text);
}

function send_admin_alert(array $d): bool
{
    if (MAIL_NOTIFY_TO === '') return false;
    $rows = [
        'Reference' => $d['reference'], 'Name' => $d['name'], 'Email' => $d['email'], 'Phone' => $d['phone'],
        'Business' => $d['business'], 'Service' => $d['service'],
    ];
    $inner = '<table style="border-collapse:collapse;width:100%;font-size:14px">';
    foreach ($rows as $k => $v) {
        $inner .= '<tr><td style="padding:6px 8px;border-bottom:1px solid #d3e0da;color:#56706b;width:110px">' . e($k) . '</td><td style="padding:6px 8px;border-bottom:1px solid #d3e0da">' . e($v ?: '-') . '</td></tr>';
    }
    $inner .= '</table><p><strong>Message</strong><br>' . nl2br(e($d['message'])) . '</p>';
    $text = "New enquiry {$d['reference']}\nName: {$d['name']}\nEmail: {$d['email']}\nPhone: {$d['phone']}\nBusiness: {$d['business']}\nService: {$d['service']}\n\n{$d['message']}\n";
    return send_mail(MAIL_NOTIFY_TO, 'New website enquiry ' . $d['reference'], email_shell('New enquiry', $inner), $text, $d['email']);
}
