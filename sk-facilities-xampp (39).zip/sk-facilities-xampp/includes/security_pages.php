<?php
/**
 * Security dropdown ke 6 pages ka content.
 * Naya text/heading badalna ho to sirf yahin badlo. Har page ka layout includes/service_page.php banata hai.
 *
 * Section types:
 *   'row'  => heading, paras[], list[] (optional), img (image ka naam, assets/img/ mein rakho)
 *   'grid' => heading, intro (optional), items [ [title, text], ... ]
 * Images abhi placeholder box hain. assets/img/ mein isi naam se .jpg/.png/.webp rakh do, wo khud dikh jayengi.
 */
return [

    'manned-guarding' => [
        'file'  => 'manned-guarding.php',
        'nav'   => 'Manned Guarding',
        'h1'    => 'Manned Guarding Service',
        'title' => 'Manned Guarding Service',
        'desc'  => 'Trained, uniformed security officers on your premises: reception, access control, patrols and event cover, planned around your site and budget.',
        'sections' => [
            ['type' => 'row', 'img' => 'manned-guarding-1', 'imglabel' => 'Manned guarding image 1', 'imgalt' => 'Security officers standing outside a building',
             'heading' => 'Secure your site, support your team',
             'paras' => [
                'A trained officer on your premises does far more than watch the door. A calm, visible presence helps your people work with confidence and keeps your site running the way you want it to.',
                'At SK Facilities Group we work as a partner, not just a supplier. Our uniformed officers fit into your organisation, from manning reception desks to meet-and-greet duties, and always present your company in the right way.',
                'Every contract begins with a site-specific survey. We learn how your premises work, what concerns you and what you expect from us, and you meet the management team who will be your point of contact from day one.',
             ]],
            ['type' => 'grid', 'heading' => 'Benefits of manned guarding',
             'items' => [
                ['On-site presence', 'Keep control and authority over who comes and goes on your premises.'],
                ['A visible deterrent', 'Uniformed officers send a clear message to anyone thinking of trying their luck.'],
                ['Lower risk', 'Stronger on-site security can support better terms when it comes to insurance.'],
                ['Confident staff', 'People work better when they know the site is looked after.'],
                ['Training taken care of', 'We train and brief our officers, so you do not have to.'],
                ['Focus on your business', 'We handle security while you get on with what you do best.'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'manned-guarding-2', 'imglabel' => 'Manned guarding image 2', 'imgalt' => 'Operator wearing a headset at a monitoring desk',
             'heading' => 'Tailored cover, checked as we go',
             'paras' => [
                'Once we understand your needs, we brief and prepare our officers for your site. Back at our office we build a security package around your requirements and budget: full-time, part-time, or one-off cover for events, seminars and meetings.',
                'We monitor our own staff so you always get the service you asked for, and as your needs change we adjust the plan. You get more than a guard on the door; you get a team committed to getting better every month.',
             ]],
        ],
    ],

    'retail-security' => [
        'file'  => 'retail-security.php',
        'nav'   => 'Retail Security',
        'h1'    => 'Retail Security',
        'title' => 'Retail Security',
        'desc'  => 'Store security for shops and retail units: visible, customer-friendly officers, loss prevention and alarm response from SK Facilities Group.',
        'sections' => [
            ['type' => 'row', 'img' => 'retail-security-1', 'imglabel' => 'Retail security image 1', 'imgalt' => 'Shoppers in a busy supermarket with CCTV monitoring',
             'heading' => 'Security that understands retail',
             'paras' => [
                'Retail changes fast and brings its own risks: theft, difficult customers, busy peak periods and tight margins. Our store security is there to protect your stock, your staff and your shoppers, so you can concentrate on serving your customers.',
             ]],
            ['type' => 'grid', 'heading' => 'Why choose SK Facilities Group for retail security',
             'items' => [
                ['Specialist training', 'Our officers are prepared for theft prevention, customer conflict and emergencies, and handle them calmly and politely.'],
                ['Visibility that matters', 'A smart, professional officer deters theft and also reflects well on your brand.'],
                ['Technology support', 'We work with cameras and alarm systems so every part of your store is covered.'],
                ['Prevention first', 'We aim to spot problems early and deal with them before they grow.'],
                ['Customer friendly', 'Officers are trained to help and guide shoppers, so security improves the visit rather than spoiling it.'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'retail-security-2', 'imglabel' => 'Retail security image 2', 'imgalt' => 'Store staff assisting a customer',
             'heading' => 'How we support your store',
             'list' => [
                'Uniformed security guards',
                'Electronic surveillance and alarm response',
                'Loss prevention strategies',
                'Emergency evacuation planning',
                'Customer assistance and support',
                'Regular security audits',
             ],
             'paras' => [
                'Retail threats keep changing, so we keep our methods up to date. Our approach protects your products and also keeps the store safe and welcoming for customers and staff.',
                'Good security should not strain your budget. We keep our retail security services competitively priced without cutting corners on quality.',
             ]],
        ],
    ],

    'alarm-response-keyholding' => [
        'file'  => 'alarm-response-keyholding.php',
        'nav'   => 'Alarm Response & Keyholding',
        'h1'    => 'Alarm Response & Keyholding',
        'title' => 'Alarm Response and Keyholding Service',
        'desc'  => 'Secure keyholding and 24/7 alarm attendance from SK Facilities Group, so you are never called out in the middle of the night.',
        'sections' => [
            ['type' => 'row', 'img' => 'alarm-response-1', 'imglabel' => 'Alarm response image', 'imgalt' => 'Alarm call point and fire alarm panel',
             'heading' => 'Your safety net when the alarm goes off',
             'paras' => [
                'Not every business needs round-the-clock guards, but an empty building can still become a target.',
                'Picture the alarm going off at 3am. Is it a false alarm or a real threat? Naming one of your own staff as keyholder is possible, but it means training them, calling them out at night and asking them to deal with a situation they may not be ready for.',
                'Our alarm response and keyholding service takes that worry away. A trained team holds your keys, attends when the alarm sounds, checks the building, deals with anything that is wrong and liaises with the emergency services when needed.',
                'You get on with running your business, knowing your premises are looked after day and night.',
             ]],
            ['type' => 'grid', 'heading' => 'What is included',
             'items' => [
                ['Secure key storage', 'Your keys are held securely and every use is logged.'],
                ['24/7 alarm attendance', 'We attend when your alarm activates, at any hour.'],
                ['Building checks on arrival', 'We check the premises, secure them and report back to you.'],
             ]],
        ],
    ],

    'cctv-installation' => [
        'file'  => 'cctv-installation.php',
        'nav'   => 'CCTV Installation',
        'h1'    => 'CCTV Installation Service',
        'title' => 'CCTV Installation Service',
        'desc'  => 'CCTV systems designed around your site, neatly installed and supported by SK Facilities Group, from site survey to ongoing maintenance.',
        'sections' => [
            ['type' => 'row', 'img' => 'cctv-installation-1', 'imglabel' => 'CCTV image 1', 'imgalt' => 'Dome CCTV camera with live camera feed on a phone',
             'heading' => 'Watching your site, all day and night',
             'paras' => [
                'Good security needs more than people on site. A well-planned CCTV system gives you round-the-clock visibility, discourages crime and gives you clear evidence if something does happen.',
                'Whether you run an office, a shop or a construction or industrial site, SK Facilities Group can design and install a system that suits it.',
             ]],
            ['type' => 'grid', 'heading' => 'From survey to support',
             'items' => [
                ['A survey first', 'We visit your site, identify the areas that matter, assess the risks and design a system to fit your needs and budget.'],
                ['Neat, reliable installation', 'We use quality equipment from trusted manufacturers and install it with as little disruption as possible: cameras, monitors, recorders and software.'],
                ['Maintenance and support', 'Our job does not end at installation. We keep your system in good working order and help when you have questions or problems.'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'cctv-installation-2', 'imglabel' => 'CCTV image 2', 'imgalt' => 'Security operator watching CCTV monitors',
             'heading' => 'Our CCTV installation benefits',
             'list' => [
                'Constant monitoring: keep an eye on your premises, 24/7',
                'Deter crime: visible cameras discourage would-be offenders',
                'Collect evidence: footage helps with incidents and disputes',
                'Cost-effective: one investment for long-term peace of mind',
                'Safer workplace: staff feel more secure at work',
             ],
             'paras' => [
                'With SK Facilities Group you get more than equipment on a wall. You get a partner who cares whether your system actually does its job.',
             ]],
        ],
    ],

    'static-security' => [
        'file'  => 'static-security.php',
        'nav'   => 'Static Security',
        'h1'    => 'Static Security',
        'title' => 'Static Security',
        'desc'  => 'Static security officers from SK Facilities Group: access control, entry and exit monitoring and a visible first line of defence for your premises.',
        'sections' => [
            ['type' => 'row', 'img' => 'static-security-1', 'imglabel' => 'Static security image 1', 'imgalt' => 'Security team at a monitoring post',
             'heading' => 'A strong first line of defence',
             'paras' => [
                'Looking after your assets, premises and people is a serious responsibility. Our static security officers stand at the heart of your site as a dependable first line of defence, giving you steady protection when you need it.',
             ]],
            ['type' => 'grid', 'heading' => 'Why choose our static security',
             'items' => [
                ['Well-trained officers', 'Our officers are prepared for a wide range of situations, observant and quick to make good decisions.'],
                ['A visible deterrent', 'The presence of a guard alone discourages unauthorised access, theft and vandalism.'],
                ['Plans built around you', 'We study your site and requirements and create a security plan that fits.'],
                ['Modern equipment', 'Officers carry up-to-date communication tools so they can respond quickly.'],
                ['Clear reporting', 'Regular reports keep you informed about incidents and observations.'],
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'static-security-2', 'imglabel' => 'Static security image 2', 'imgalt' => 'Security officer screening visitors with a hand scanner',
             'heading' => 'Services we provide',
             'list' => [
                'Entry and exit monitoring',
                'Regular premises patrolling',
                'Emergency response coordination',
                'Access control for visitors and staff',
                'CCTV monitoring (where applicable)',
                'Alarm system oversight',
             ],
             'paras' => [
                'Our officers respond quickly, present themselves professionally so visitors get a good first impression, and keep their training up to date as security practice changes.',
                'We do all this at competitive prices, so your site is protected without straining your budget.',
             ]],
        ],
    ],

    'vacant-premises-inspection' => [
        'file'  => 'vacant-premises-inspection.php',
        'nav'   => 'Vacant Premises Inspection',
        'h1'    => 'Vacant Premises Inspection',
        'title' => 'Vacant Premises Inspection',
        'desc'  => 'Keyholding, regular inspections and reporting for empty properties, with one point of contact for everything a vacant site needs.',
        'sections' => [
            ['type' => 'row', 'img' => 'vacant-premises-1', 'imglabel' => 'Vacant premises image 1', 'imgalt' => 'Team walking through an empty commercial unit',
             'heading' => 'Protect your empty property, simplify your management',
             'paras' => [
                'Sooner or later every property manager has an empty building to look after. Each one is different, depending on things like:',
             ],
             'list' => [
                'Location',
                'Security requirements',
                'State of repair',
                'Utilities and power',
                'Impact on neighbouring properties',
                'How long until it is re-let',
                'Pest control',
             ]],
            ['type' => 'row', 'flip' => true, 'img' => 'vacant-premises-2', 'imglabel' => 'Vacant premises image 2', 'imgalt' => 'Inspector recording notes on a clipboard',
             'heading' => 'One service for the whole site',
             'paras' => [
                'Managing all of this usually means several contractors and someone to give each of them access to the site. It quickly becomes complicated and time-consuming.',
                'As a security contractor, SK Facilities Group can hold your keys, directly or through trusted partners. We cover the security of the site, carry out inspections and patrols to your schedule, and send you regular reports on its condition.',
                'We can also bring in trusted contractors for the other work a vacant site needs, so everything is arranged through us.',
             ]],
            ['type' => 'grid', 'heading' => 'The SK difference',
             'items' => [
                ['Controlled access', 'As keyholder, we manage and record every visit to your site.'],
                ['Flexible deployment', 'Our trusted contractors can be arranged around your timetable.'],
                ['One point of contact', 'No more juggling suppliers; you speak to one team.'],
                ['Simple invoicing', 'One provider means one clear invoice.'],
                ['Clear audit trail', 'A single record of everything that happened on site, and when.'],
             ]],
        ],
    ],

];
