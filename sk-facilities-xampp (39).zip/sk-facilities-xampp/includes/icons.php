<?php
function icon(string $name, string $cls = ''): string
{
    static $p = [
        'send' => '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
        'leaf' => '<path d="M5 19c0-8 5-14 15-14 0 10-6 15-14 15"/><path d="M5 19c3-5 6-8 10-10"/>',
        'tree' => '<path d="M12 21v-6"/><path d="M12 3l5 6h-3l4 5H6l4-5H7l5-6z"/>',
        'flower' => '<circle cx="12" cy="10" r="2"/><path d="M12 8c-1-3 0-5 0-5s1 2 0 5zM14 10c3-1 5 0 5 0s-2 1-5 0zM12 12c1 3 0 5 0 5s-1-2 0-5zM10 10c-3 1-5 0-5 0s2-1 5 0z"/><path d="M12 14v7M12 18c-2 0-3-1-4-2"/>',
        'shield' => '<path d="M12 3l7 3v5c0 4.5-3 8.2-7 10-4-1.8-7-5.5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
        'car' => '<path d="M5 16V11l2-5h10l2 5v5"/><path d="M3 16h18v3H3z"/><circle cx="7.5" cy="13.5" r=".8"/><circle cx="16.5" cy="13.5" r=".8"/>',
        'bag' => '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6a3 3 0 016 0v2"/>',
        'key' => '<circle cx="8" cy="14" r="4"/><path d="M11 11l9-8M16 6l3 3M14 8l2 2"/>',
        'camera' => '<path d="M3 8h13v8H3z"/><path d="M16 11l5-3v8l-5-3"/>',
        'tower' => '<path d="M7 21V8l5-5 5 5v13"/><path d="M4 21h16M10 12h4M10 16h4"/>',
        'sparkle' => '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3z"/><path d="M18 16l.7 1.8 1.8.7-1.8.7L18 21l-.7-1.8-1.8-.7 1.8-.7L18 16z"/>',
        'home' => '<path d="M4 11l8-7 8 7"/><path d="M6 10v10h12V10"/><path d="M10 20v-6h4v6"/>',
        'hammer' => '<path d="M14 5l5 5-3 3-5-5 3-3z"/><path d="M12 10L4 18l2 2 8-8"/>',
        'door' => '<path d="M6 21V4h12v17"/><path d="M4 21h16"/><circle cx="15" cy="13" r=".8"/>',
        'cross' => '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M12 8v8M8 12h8"/>',
        'badge' => '<circle cx="12" cy="9" r="5"/><path d="M9 13.5L8 21l4-2 4 2-1-7.5"/>',
        'refresh' => '<path d="M20 11a8 8 0 00-14-4L4 9"/><path d="M4 4v5h5"/><path d="M4 13a8 8 0 0014 4l2-2"/><path d="M20 20v-5h-5"/>',
        'users' => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.5-4 3-6 6.5-6s6 2 6.5 6"/><path d="M16 5a3.2 3.2 0 010 6M18 14c2 .6 3.3 2.4 3.5 6"/>',
        'bolt' => '<path d="M13 3L5 13h6l-1 8 8-10h-6l1-8z"/>',
        'pencil' => '<path d="M4 20l1-5L16 4l4 4L9 19l-5 1z"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'map' => '<path d="M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
        'pound' => '<circle cx="12" cy="12" r="9"/><path d="M14.5 8.5a3 3 0 00-5 2V15H8M8 15h7M9.5 12H13"/>',
        'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
        'check' => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
        'arrow' => '<path d="M4 12h15M13 6l6 6-6 6"/>',
        'chat' => '<path d="M4 5h16v11H9l-5 4V5z"/><path d="M8 9h8M8 12h5"/>',
        'chev' => '<path d="M6 9l6 6 6-6"/>',
        'close' => '<path d="M6 6l12 12M18 6L6 18"/>',
        'whatsapp' => '<path d="M4 20l1.3-4.2A8 8 0 118.3 18.8L4 20z"/><path d="M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .7c-1-.4-1.8-1.2-2.2-2.2l.7-1-1-2L9 9z"/>',
    ];
    $body = $p[$name] ?? $p['shield'];
    return '<svg class="ico ' . $cls . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $body . '</svg>';
}
